$(document).ready(function() {
	//sortable
	$("#image_list").sortable();
	//img swap
	$("li").click(function() {
		console.log("clicked!");
		$(this).children($("img")).toggle();
	});
});